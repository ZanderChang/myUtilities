#undef VERSION
#undef PACKAGE
